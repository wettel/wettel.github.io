CodeCity - Version 1.418 November 2009http://codecity.inf.usi.ch

Richard Wettele-mail: richard.wettel@usi.ch


New in version 1.4:

Brief description
Noticeable performance optimizations, lots of hot new features, and massive UI redesign and usability improvements

Detailed description
Optimizations:
- performed optimizations in the model part, which allows now much faster building of code cities even for very large systems (just look at how fast ArgoUML is built compared to the previous versions)
- improved the filtering of non-model entities (now also it removes the package hierarchies) and it has also become very fast
New features:
- added support for exporting high-resolution pictures (in jpeg format) which allows the user to specify the printing size (A5 to A0), both as single snapshots and as evolution snapshots (one picture per version taken automatically). This will allow anyone to print and hang impressive posters of their systems visualized in CodeCity!
- the age map button is now a switch button, which provides the possibility to remove the age map (reapply the mapped colors) at any time and allows it to be persistent during time traveling
- added a tree view (currently available only in the single version visualization), which only expands as necessary to show the selected items and which is synchronized with the city view in terms of selection. The tree view can be show/hidden via a switch button
- added support for terms (thanks to the work of Adrian Kuhn): hovering the mouse over a building shows the top terms of the class (extracted from the names of the classes) and there is a new term-based search feature
- added a new default view configuration which builds on top of the previous coarse grained one, and adds the number of lines of code mapped on the color of the buildings (dark gray to intense blue)
- added basic support to adding edges on-the-fly for the selected classes
- added a browse source code button (however you need to place the source code of the system in a particular folder relative to where you keep your application, see the FAQ section on the web page)
- added support in the isometric perspective for placing the city at the most appropriate distance which makes it best fit in the view. In the evolution visualization, the entire evolution is taken into account in order to provide an initial position which best fits any version, to allow time traveling without the need of adjusting the perspective
- added a second perspective, namely top-view, which allows one to see a satellite-view of the city
Usability and UI improvements
- completely redesigned the info panel, to show only the important information and to do it in a pleasant way: formatted text and the metric values are human-readable :)
- redesigned the status bar 
- changed the additive selection command key from SHIFT to CTRL, to match the majority of editors
- added the possibility to show or hide the information panel
- added a progress bar for the last part of the model importing process (the longest one)
- the default colors for the class-level disharmonies in the disharmony maps is now in the range of yellow-orange-red-purple, and does not include blue anymore (to not be confusing with the new configurations in which a blue class is one with a large LOC metric)
- the Disharmony Map UI now provides a color (gray by default) for the non-affected classes, which allows one to apply a disharmony map on any view configuration without the risk of color clashing
- improved robustness during model import/export operations: an exception thrown during such an operation does not cause CodeCity to exit anymore
- updated most of the icons in the toolbar to provide a consistent look and feel
- designed a new application icon
- changed the system that appears in the preview pane to a fairly larger one
- fixed all the known bugs

Installation:
You need to have VisualWorks Smalltalk installed on your system. Then unzip the image file (codecity.im). 

Running:
Open the VisualWorks application and point it to the codecity.im image file. The first view is already loaded. You can visualize any of the systems provided with the tool, or load any other system if you have it in MSE format. For more information on MSE, visit http://moose.unibe.ch/docs/mse.

Uninstalling:
Simply delete the application.