To get started, see doc/index.html and doc/manual/index.html

The FindBugs source license is in the file LICENSE.txt

Both the name FindBugs and the FindBugs bug mark are
trademarked by the University of Maryland.

The Apache BCEL license is in the file LICENSE-bcel.txt

The ASM license is in the file LICENSE-ASM.txt

The dom4j license is in the file LICENSE-dom4j.txt

The AppleJavaExtensions license is in the file LICENSE-AppleJavaExtensions.txt

The Docbook 4.2 XML DTD license is in the file LICENSE-docbook.txt

The JSR-305 reference implementation license is in LICENSE-jsr305.txt

The Jaxen license is in LICENSE-jaxen.txt
