package edu.umd.cs.findbugs.ba.obl;

/**
 * Enumeration describing possible actions
 * for policy database entries.
 */
public enum ObligationPolicyDatabaseActionType {

	ADD, DEL, CLEAR
}
